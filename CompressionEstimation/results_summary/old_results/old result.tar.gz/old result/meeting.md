

1. prefex sampling data under abe(Abslute Error)

![fig-1](./Figure-1.png)



2. block interval samling data under pw(point-wise)
![fig-2](./Figure-2.png)